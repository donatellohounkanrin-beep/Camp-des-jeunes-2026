CAMP NATIONAL JEMEVE 2026 — J'Y SERAI

1. Décompressez ce dossier.
2. Hébergez index.html et affiche.jpg sur un hébergeur statique gratuit comme GitHub Pages.
3. Partagez le lien obtenu dans WhatsApp.
4. Le participant clique sur « Ajouter ma photo », choisit sa photo, puis télécharge son affiche.

Le fichier index.html contient déjà toute la logique de personnalisation.
